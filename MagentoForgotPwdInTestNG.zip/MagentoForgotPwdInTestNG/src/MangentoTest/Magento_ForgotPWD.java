package MangentoTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import Initialization.WebDriverLaunch;

import magentoPages.ForgotPwdPage;
import magentoPages.HomePage;
import magentoPages.LoginPage;
import utilities.PropertiesFileHandler;

public class Magento_ForgotPWD extends WebDriverLaunch {
	
	@Test
	public void ForgotPasswordCheck() throws InterruptedException
	{
		String url=hashData.get("url");
		String username=hashData.get("invalidusername");
		String actualPwdMsg=hashData.get("actualForgotPWDMsg");
		String ExForgotPWDMsg=hashData.get("expectedForgotPWDMsg");
		String invalidEmail=hashData.get("invalidEmail");
		String actualInvalidEmailMsg=hashData.get("actualInvalidMsg");
		String ExInvalidEmailMsg=hashData.get("ExInvalidEmailMsg");
		String actualReqEmailMsg=hashData.get("actualReqEmailMsg");
		String SuccessPageSrc;
		String InvalidPageSrc;
		String RequireEmaiPgSrc;
		driver.get(url);
		//Home Page
		HomePage home=new HomePage(driver);
		home.clickOnMyAccountIcon();
		
		//Login Page
		LoginPage login = new LoginPage(driver, wait);
		login.clickonForgotPWD();
		
		//Forgot PWD Page
		ForgotPwdPage fPwd=new ForgotPwdPage(driver,wait);
		
		//for empty email ID
		fPwd.clickOnSubmit();
		RequireEmaiPgSrc=fPwd.getPgSrcORequireEmail();
		Assert.assertTrue(RequireEmaiPgSrc.contains(actualReqEmailMsg), "Assertion on Required field");		
		System.out.println("Enter Email ID..this is a required field");
		
		//Forgot PWD for correct email ID format
		Thread.sleep(3000);
		fPwd.enterEmail(username);
		fPwd.clickOnSubmit();
		SuccessPageSrc=fPwd.getPgSrcOfSuccessMsg();		
		Assert.assertTrue(SuccessPageSrc.contains(actualPwdMsg), ExForgotPWDMsg);
				
		//Forgot PWD for incorrect email ID format	
		login.clickonForgotPWD();
		Thread.sleep(3000);
		fPwd.enterEmail(invalidEmail);
		fPwd.clickOnSubmit();
		if (fPwd.emailValidation(invalidEmail))
		{		
			
			System.out.println("Email entered is valid");
		}
		else
		{	
			InvalidPageSrc=fPwd.getPgSrcOfInvalidMsg();
			Assert.assertTrue(InvalidPageSrc.contains(actualInvalidEmailMsg),ExInvalidEmailMsg);
			System.out.println("Entered Invalid Email");
		}
		
	}

}
