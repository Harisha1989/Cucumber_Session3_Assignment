package Initialization;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import utilities.PropertiesFileHandler;

public class WebDriverLaunch {
	
	public WebDriver driver;
	public WebDriverWait wait;
	public PropertiesFileHandler propFileHandle;
	public HashMap<String,String> hashData;
	
	@BeforeSuite
	public void preSetForTest() throws IOException
	{
		String file="./TestData/magentoData.properties";
		propFileHandle =new PropertiesFileHandler();
		hashData=propFileHandle.getPropertiesfromHashMap(file);
	}	
	
	@BeforeMethod
	@Parameters({"browser"})
	public void initialisation(@Optional("ch")String browser)
	{		
		browserInitialization(browser);
		/*System.setProperty("webdriver.gecko.driver", "./Drivers/geckodriver.exe");
		driver=new FirefoxDriver();*/
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		wait=new WebDriverWait(driver, 60);		
	}
	@AfterMethod
	public void closingBrowser()
	{
		driver.quit();
	}
	
	public void browserInitialization(String browser) 
	{
		switch(browser.toLowerCase())
		{
		case "ff":
			System.setProperty("webdriver.gecko.driver", "./Drivers/geckodriver.exe");
			driver=new FirefoxDriver();
			break;
		case "ch":
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
			driver=new ChromeDriver();
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", "./Drivers/IEDriverServer.exe");
			driver=new InternetExplorerDriver();
			break;
		}
	}
}
	
